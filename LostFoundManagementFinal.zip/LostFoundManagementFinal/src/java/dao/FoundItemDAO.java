
package dao;

import model.FoundItem;
import java.sql.*;
import java.util.*;

public class FoundItemDAO {
    private static final String DB_URL = "jdbc:derby://localhost:1527/LostAndFoundDB";
    private static final String DB_USER = "app";
    private static final String DB_PASS = "app";

    public List<FoundItem> getRecentFoundItems(int limit) {
        List<FoundItem> items = new ArrayList<>();
        String sql = "SELECT fi.ID, fi.ITEM_NAME, fi.DESCRIPTION, fi.DATE_FOUND, fi.LOCATION_FOUND, " +
                     "fi.REPORTED_BY, fi.STATUS, u.PHONE_NUM " +
                     "FROM FOUND_ITEMS fi " +
                     "JOIN USERS u ON fi.REPORTED_BY = u.USERNAME " +
                     "ORDER BY fi.DATE_FOUND DESC FETCH FIRST ? ROWS ONLY";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, limit);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                FoundItem item = new FoundItem();
                item.setId(rs.getInt("ID"));
                item.setItemName(rs.getString("ITEM_NAME"));
                item.setDescription(rs.getString("DESCRIPTION"));
                item.setDate(rs.getDate("DATE_FOUND").toString());
                item.setLocation(rs.getString("LOCATION_FOUND"));
                item.setReportedBy(rs.getString("REPORTED_BY"));
                item.setStatus(rs.getString("STATUS"));
                item.setImageId(rs.getInt("ID"));
                item.setPhoneNumber(rs.getString("PHONE_NUM"));
                items.add(item);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return items;
    }
}

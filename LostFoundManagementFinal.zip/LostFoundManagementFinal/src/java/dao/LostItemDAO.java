package dao;

import model.LostItem;
import java.sql.*;
import java.util.*;

public class LostItemDAO {

    private static final String DB_URL = "jdbc:derby://localhost:1527/LostAndFoundDB";
    private static final String DB_USER = "app";
    private static final String DB_PASS = "app";

    public List<LostItem> getRecentLostItems(int limit) {
        List<LostItem> items = new ArrayList<>();

        String query = "SELECT li.ID, li.ITEM_NAME, li.DESCRIPTION, li.DATE_LOST, li.LOCATION, " +
                       "li.REPORTED_BY, li.STATUS, u.PHONE_NUM " +
                       "FROM LOST_ITEMS li " +
                       "JOIN USERS u ON li.REPORTED_BY = u.USERNAME " +
                       "ORDER BY li.DATE_LOST DESC FETCH FIRST " + limit + " ROWS ONLY";

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(query)) {

                while (rs.next()) {
                    LostItem item = new LostItem();
                    item.setId(rs.getInt("ID"));
                    item.setItemName(rs.getString("ITEM_NAME"));
                    item.setDescription(rs.getString("DESCRIPTION"));
                    item.setDate(rs.getDate("DATE_LOST").toString());
                    item.setLocation(rs.getString("LOCATION"));
                    item.setReportedBy(rs.getString("REPORTED_BY"));
                    item.setStatus(rs.getString("STATUS"));
                    item.setPhoneNumber(rs.getString("PHONE_NUM"));
                    item.setImageId(rs.getInt("ID"));
                    items.add(item);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return items;
    }
}
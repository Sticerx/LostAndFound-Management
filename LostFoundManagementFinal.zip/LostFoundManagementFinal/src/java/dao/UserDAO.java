
package dao;

import model.User;
import java.sql.*;

public class UserDAO {
    private static final String DB_URL = "jdbc:derby://localhost:1527/LostAndFoundDB";
    private static final String DB_USER = "app";
    private static final String DB_PASS = "app";

    public User getUserByUsername(String username) {
        User user = null;
        String sql = "SELECT * FROM USERS WHERE USERNAME = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                user = new User();
                user.setUsername(rs.getString("USERNAME"));
                user.setPassword(rs.getString("PASSWORD"));
                user.setPhoneNumber(rs.getString("PHONE_NUM"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return user;
    }
}

package servlet;

import java.io.*;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:derby://localhost:1527/LostAndFoundDB";
    private static final String DB_USER = "app";
    private static final String DB_PASS = "app";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Optional: basic input trimming
        if (username != null) username = username.trim();
        if (password != null) password = password.trim();

        try (PrintWriter out = response.getWriter()) {

            // Simple validation
            if (username == null || password == null || username.isEmpty() || password.isEmpty()) {
                out.println("<p style='color:red;'>Username and password cannot be empty.</p>");
                out.println("<a href='register.jsp'>Back to Register</a>");
                return;
            }

            Class.forName("org.apache.derby.jdbc.ClientDriver");

            try (
                Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
                PreparedStatement checkStmt = conn.prepareStatement("SELECT * FROM USERS WHERE USERNAME = ?")
            ) {
                checkStmt.setString(1, username);
                try (ResultSet rs = checkStmt.executeQuery()) {
                    if (rs.next()) {
                        out.println("<p style='color:red;'>Username already exists.</p>");
                        out.println("<a href='register.jsp'>Try Again</a>");
                        return;
                    }
                }

                // Insert new user
                try (PreparedStatement insertStmt = conn.prepareStatement(
                        "INSERT INTO USERS (USERNAME, PASSWORD) VALUES (?, ?)")) {

                    insertStmt.setString(1, username);
                    insertStmt.setString(2, password); // In production, hash the password!

                    int rows = insertStmt.executeUpdate();

                    if (rows > 0) {
                        response.sendRedirect("login.jsp");
                    } else {
                        out.println("<p style='color:red;'>Registration failed. Please try again.</p>");
                        out.println("<a href='register.jsp'>Try Again</a>");
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            try (PrintWriter out = response.getWriter()) {
                out.println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
                out.println("<a href='register.jsp'>Back</a>");
            }
        }
    }
}

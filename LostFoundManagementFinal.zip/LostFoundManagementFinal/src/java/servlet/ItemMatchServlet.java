package servlet;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet("/ItemMatchServlet")
public class ItemMatchServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:derby://localhost:1527/LostAndFoundDB";
    private static final String DB_USER = "app";
    private static final String DB_PASS = "app";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<MatchedItem> lostItems = new ArrayList<>();
        List<MatchedItem> foundItems = new ArrayList<>();

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");

            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {

                lostItems = fetchLostItems(conn);
                foundItems = fetchFoundItems(conn);

                matchItems(conn, lostItems, foundItems);

                request.setAttribute("lostItems", lostItems);
                request.setAttribute("foundItems", foundItems);
                request.getRequestDispatcher("viewItems.jsp").forward(request, response);

            }

        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("text/html");
            response.getWriter().println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
        }
    }

    private List<MatchedItem> fetchLostItems(Connection conn) throws SQLException {
        List<MatchedItem> items = new ArrayList<>();
        String sql = "SELECT li.*, u.PHONE_NUM FROM LOST_ITEMS li LEFT JOIN USERS u ON li.REPORTED_BY = u.USERNAME";


        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                MatchedItem item = new MatchedItem();
                item.setId(rs.getInt("ID"));
                item.setItemName(rs.getString("ITEM_NAME"));
                item.setDescription(rs.getString("DESCRIPTION"));
                item.setDate(rs.getDate("DATE_LOST").toString());
                item.setLocation(rs.getString("LOCATION"));
                item.setReportedBy(rs.getString("REPORTED_BY"));
                item.setPhoneNumber(rs.getString("PHONE_NUM")); 

                item.setStatus(rs.getString("STATUS"));
                items.add(item);
            }
        }

        return items;
    }

    private List<MatchedItem> fetchFoundItems(Connection conn) throws SQLException {
        List<MatchedItem> items = new ArrayList<>();
        String sql = "SELECT fi.*, u.PHONE_NUM FROM FOUND_ITEMS fi LEFT JOIN USERS u ON fi.REPORTED_BY = u.USERNAME";


        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                MatchedItem item = new MatchedItem();
                item.setId(rs.getInt("ID"));
                item.setItemName(rs.getString("ITEM_NAME"));
                item.setDescription(rs.getString("DESCRIPTION"));
                item.setDate(rs.getDate("DATE_FOUND").toString());
                item.setLocation(rs.getString("LOCATION_FOUND"));
                item.setReportedBy(rs.getString("REPORTED_BY"));
                item.setPhoneNumber(rs.getString("PHONE_NUM"));
                item.setStatus(rs.getString("STATUS"));
                items.add(item);
            }
        }

        return items;
    }

    private void matchItems(Connection conn, List<MatchedItem> lostItems, List<MatchedItem> foundItems) throws SQLException {
        for (MatchedItem lost : lostItems) {
            for (MatchedItem found : foundItems) {
                if (itemsMatch(lost, found)) {
                    lost.setMatched(true);
                    found.setMatched(true);
                    updateStatus(conn, "LOST_ITEMS", lost.getId(), "Matched");
                    updateStatus(conn, "FOUND_ITEMS", found.getId(), "Matched");
                    break;
                }
            }
        }
    }

    private boolean itemsMatch(MatchedItem lost, MatchedItem found) {
        return lost.getItemName().equalsIgnoreCase(found.getItemName()) &&
               lost.getDate().equals(found.getDate()) &&
               lost.getLocation().equalsIgnoreCase(found.getLocation());
    }

    private void updateStatus(Connection conn, String tableName, int id, String newStatus) throws SQLException {
        String sql = "UPDATE " + tableName + " SET STATUS = ? WHERE ID = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newStatus);
            ps.setInt(2, id);
            ps.executeUpdate();
        }
    }
}

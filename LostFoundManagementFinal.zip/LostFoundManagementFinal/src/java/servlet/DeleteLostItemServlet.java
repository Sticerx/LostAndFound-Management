package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DeleteLostItemServlet")
public class DeleteLostItemServlet extends HttpServlet {
    private static final String DB_URL = "jdbc:derby://localhost:1527/LostAndFoundDB";
    private static final String DB_USER = "app";
    private static final String DB_PASS = "app";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String idParam = request.getParameter("id");

        // Validate that the ID is present and numeric
        if (idParam == null || idParam.isEmpty()) {
            System.err.println("Missing 'id' parameter");
            response.sendRedirect("ItemMatchServlet?error=missing_id");
            return;
        }

        try {
            int id = Integer.parseInt(idParam);
            Class.forName("org.apache.derby.jdbc.ClientDriver");

            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
                 PreparedStatement ps = conn.prepareStatement("DELETE FROM LOST_ITEMS WHERE ID=?")) {

                ps.setInt(1, id);
                int rows = ps.executeUpdate();

                if (rows == 0) {
                    System.err.println("No lost item found with ID: " + id);
                } else {
                    System.out.println("Lost item with ID " + id + " deleted.");
                }

            }

        } catch (NumberFormatException e) {
            System.err.println("Invalid ID format: " + idParam);
        } catch (Exception e) {
            e.printStackTrace();
        }

        response.sendRedirect("ItemMatchServlet");
    }
}

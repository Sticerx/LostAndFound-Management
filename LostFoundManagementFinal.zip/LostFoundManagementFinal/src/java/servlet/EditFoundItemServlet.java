package servlet;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/EditFoundItemServlet")
@MultipartConfig(maxFileSize = 1024 * 1024 * 5) // 5MB max
public class EditFoundItemServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:derby://localhost:1527/LostAndFoundDB";
    private static final String DB_USER = "app";
    private static final String DB_PASS = "app";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws IOException, ServletException {

        String idParam = request.getParameter("id");
        String itemName = request.getParameter("itemName");
        String description = request.getParameter("description");
        String dateFound = request.getParameter("dateFound"); // Kept as dateLost for form compatibility
        String location = request.getParameter("location");
        String status = request.getParameter("status");

        Part imagePart = request.getPart("image");
        InputStream imageInputStream = null;

        try {
            int id = Integer.parseInt(idParam);
            Date foundDate = Date.valueOf(dateFound); // Format: YYYY-MM-DD

            Class.forName("org.apache.derby.jdbc.ClientDriver");

            boolean imageProvided = imagePart != null && imagePart.getSize() > 0;

            String sql;
            if (imageProvided) {
                sql = "UPDATE FOUND_ITEMS SET ITEM_NAME=?, DESCRIPTION=?, DATE_FOUND=?, LOCATION_FOUND=?, STATUS=?, IMAGE_PATH=? WHERE ID=?";
            } else {
                sql = "UPDATE FOUND_ITEMS SET ITEM_NAME=?, DESCRIPTION=?, DATE_FOUND=?, LOCATION_FOUND=?, STATUS=? WHERE ID=?";
            }

            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
                 PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, itemName);
                ps.setString(2, description);
                ps.setDate(3, foundDate);
                ps.setString(4, location);
                ps.setString(5, status); 

                if (imageProvided) {
                    imageInputStream = imagePart.getInputStream();
                    ps.setBinaryStream(6, imageInputStream, imagePart.getSize());
                    ps.setInt(7, id);
                } else {
                    ps.setInt(6, id);
                }

                int updatedRows = ps.executeUpdate();
                System.out.println("EditFoundItemServlet: Updated rows = " + updatedRows);

                if (updatedRows == 0) {
                    System.err.println("EditFoundItemServlet: No item found with ID = " + id);
                }

            }

        } catch (NumberFormatException e) {
            System.err.println("Invalid ID format: " + idParam);
        } catch (IllegalArgumentException e) {
            System.err.println("Invalid date format: " + dateFound);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Redirect regardless
        response.sendRedirect("ItemMatchServlet");
    }
}

package servlet;

import dao.LostItemDAO;
import model.LostItem;
import dao.FoundItemDAO;
import model.FoundItem;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/HomeServlet")
public class HomeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        LostItemDAO lostItemDAO = new LostItemDAO();
        List<LostItem> lostItems = lostItemDAO.getRecentLostItems(3);
        FoundItemDAO foundItemDAO = new FoundItemDAO();
        List<FoundItem> foundItems = foundItemDAO.getRecentFoundItems(3);

        request.setAttribute("lostSample", lostItems);
        request.setAttribute("foundSample", foundItems);
        request.getRequestDispatcher("index.jsp").forward(request, response);
    }
}
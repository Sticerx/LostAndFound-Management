package servlet;

public class MatchedItem {
    private int id;
    private String itemName;
    private String description;
    private String date;
    private String location;
    private String reportedBy;
    private String status; 
    private int imageId;
    private String phoneNumber;
    public boolean isMatched;

    public MatchedItem() {
    }

    public MatchedItem(int id, String itemName, String description, String date, String location, String reportedBy, String phoneNumber) {
        this.id = id;
        this.itemName = itemName;
        this.description = description;
        this.date = date;
        this.location = location;
        this.reportedBy = reportedBy;
        this.phoneNumber = phoneNumber;
        this.isMatched = false;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getItemName() {
        return itemName;
    }

    public String getDescription() {
        return description;
    }

    public String getDate() {
        return date;
    }

    public String getLocation() {
        return location;
    }

    public String getReportedBy() {
        return reportedBy;
    }

    public boolean isMatched() {
        return isMatched;
    }

    public String getStatus() {
        return status;
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }
    
    public int getImageId() {
        return imageId;
    }
    
    
    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setReportedBy(String reportedBy) {
        this.reportedBy = reportedBy;
    }

    public void setMatched(boolean matched) {
        isMatched = matched;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    public void setImageId(int imageId) {
        this.imageId = imageId;
    }
}

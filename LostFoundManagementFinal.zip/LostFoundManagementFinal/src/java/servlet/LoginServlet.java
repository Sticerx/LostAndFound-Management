package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.annotation.WebServlet;
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:derby://localhost:1527/LostAndFoundDB";
    private static final String DB_USER = "app";
    private static final String DB_PASS = "app";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Optional: trim input to prevent accidental whitespace issues
        if (username != null) username = username.trim();
        if (password != null) password = password.trim();

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");

            try (
                Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)
            ) {
                // Step 1: Check if username exists
                String checkUserSQL = "SELECT * FROM USERS WHERE USERNAME = ?";
                try (PreparedStatement userCheck = conn.prepareStatement(checkUserSQL)) {
                    userCheck.setString(1, username);
                    ResultSet userRs = userCheck.executeQuery();
                    if (!userRs.next()) {
                        response.sendRedirect("login.jsp?error=notfound");
                        return;
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
                }

                // Step 2: If username exists, now check for correct password
                String sql = "SELECT * FROM USERS WHERE USERNAME = ? AND PASSWORD = ?";
                try (PreparedStatement pst = conn.prepareStatement(sql)) {
                    pst.setString(1, username);
                    pst.setString(2, password);

                    try (ResultSet rs = pst.executeQuery()) {
                        if (rs.next()) {
                            HttpSession session = request.getSession();
                            session.setAttribute("username", username);
                            response.sendRedirect("HomeServlet");
                        } else {
                            response.sendRedirect("login.jsp?error=invalid");
                        }
                    }
                }

}           catch (SQLException ex) {
                Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
    }   catch (ClassNotFoundException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

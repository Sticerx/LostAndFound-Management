package servlet;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/LostItemServlet")
@MultipartConfig(maxFileSize = 1024 * 1024 * 5) // 5MB max image size
public class LostItemServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:derby://localhost:1527/LostAndFoundDB";
    private static final String DB_USER = "app";
    private static final String DB_PASS = "app";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        String itemName = request.getParameter("itemName");
        String description = request.getParameter("description");
        String dateLost = request.getParameter("dateLost");
        String location = request.getParameter("location");
        String reportedBy = request.getParameter("reportedBy");

        InputStream imageInputStream = null;
        Part imagePart = request.getPart("image");
        if (imagePart != null && imagePart.getSize() > 0) {
            imageInputStream = imagePart.getInputStream();
        }

        try (PrintWriter out = response.getWriter()) {

            // Basic validation
            if (itemName == null || description == null || dateLost == null || location == null || reportedBy == null ||
                itemName.isEmpty() || description.isEmpty() || dateLost.isEmpty() || location.isEmpty() || reportedBy.isEmpty()) {
                out.println("<p style='color:red;'>All fields except image are required.</p>");
                out.println("<a href='lost.jsp'>Go Back</a>");
                return;
            }

            // Register JDBC driver and connect
            Class.forName("org.apache.derby.jdbc.ClientDriver");

            String sql = "INSERT INTO LOST_ITEMS (ITEM_NAME, DESCRIPTION, DATE_LOST, LOCATION, REPORTED_BY, IMAGE_PATH) " +
                         "VALUES (?, ?, ?, ?, ?, ?)";

            try (
                Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
                PreparedStatement pst = conn.prepareStatement(sql)
            ) {
                pst.setString(1, itemName);
                pst.setString(2, description);
                pst.setDate(3, Date.valueOf(dateLost)); // Make sure the input is in YYYY-MM-DD
                pst.setString(4, location);
                pst.setString(5, reportedBy);

                if (imageInputStream != null) {
                    pst.setBinaryStream(6, imageInputStream, imagePart.getSize());
                } else {
                    pst.setNull(6, java.sql.Types.BLOB);
                }

                int rows = pst.executeUpdate();

                if (rows > 0) {
                    response.sendRedirect("ItemMatchServlet");
                } else {
                    out.println("<p style='color:red;'>Failed to report lost item.</p>");
                    out.println("<a href='lost.jsp'>Go Back</a>");
                }

            }

        } catch (IllegalArgumentException e) {
            response.getWriter().println("<p style='color:red;'>Invalid date format. Please use YYYY-MM-DD.</p>");
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
        }
    }
}

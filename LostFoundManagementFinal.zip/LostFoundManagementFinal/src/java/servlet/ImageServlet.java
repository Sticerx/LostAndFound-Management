package servlet;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.ServletContext;

@WebServlet("/ImageServlet")
public class ImageServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:derby://localhost:1527/LostAndFoundDB";
    private static final String DB_USER = "app";
    private static final String DB_PASS = "app";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String idParam = request.getParameter("id");
        String type = request.getParameter("type"); // "lost" or "found"

        if (idParam == null || type == null) {
            response.setContentType("text/plain");
            response.getWriter().write("Missing id or type parameter.");
            return;
        }

        try {
            int id = Integer.parseInt(idParam);
            Class.forName("org.apache.derby.jdbc.ClientDriver");

            String tableName = type.equalsIgnoreCase("lost") ? "LOST_ITEMS" : "FOUND_ITEMS";
            String sql = "SELECT IMAGE_PATH FROM " + tableName + " WHERE ID=?";

            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
                 PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    Blob imageBlob = rs.getBlob("IMAGE_PATH");
                    if (imageBlob != null) {
                        response.setContentType("image/jpeg"); // assume image is JPEG
                        try (InputStream in = imageBlob.getBinaryStream();
                             OutputStream out = response.getOutputStream()) {

                            byte[] buffer = new byte[4096];
                            int bytesRead;
                            while ((bytesRead = in.read(buffer)) != -1) {
                                out.write(buffer, 0, bytesRead);
                            }
                        }
                        return;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // If no image found or error occurs, show the placeholder image
        servePlaceholderImage(request, response);
    }

    private void servePlaceholderImage(HttpServletRequest request, HttpServletResponse response) throws IOException {
        ServletContext context = getServletContext();
        String placeholderPath = "/img/placeholderimage.jpg"; // adjust path as needed
        InputStream placeholderStream = context.getResourceAsStream(placeholderPath);

        if (placeholderStream == null) {
            response.setContentType("text/plain");
            response.getWriter().write("Placeholder image not found.");
            return;
        }

        response.setContentType("image/jpeg");
        try (OutputStream out = response.getOutputStream()) {
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = placeholderStream.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }
        }
    }
}
